Code from tutorial here:
http://www.javascript-coder.com/javascript-form/javascript-calculator-script.phtml

This source is shared under the terms of LGPL 3
www.gnu.org/licenses/lgpl.html

You are free to use the code in Commercial or non-commercial projects